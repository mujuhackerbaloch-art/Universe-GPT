from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from universe_model import UniverseGPT

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
app = Flask(__name__, static_folder=str(STATIC), static_url_path="/static")
model = UniverseGPT()


def web_notes(query: str) -> list[dict]:
    notes: list[dict] = []
    try:
        url = "https://en.wikipedia.org/api/rest_v1/page/summary/" + urllib.parse.quote(query.replace(" ", "_"))
        req = urllib.request.Request(url, headers={"User-Agent": "UniverseGPT/1.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
        if data.get("extract"):
            notes.append({"title": data.get("title") or query, "snippet": data.get("extract")})
    except Exception:
        pass
    return notes


@app.get("/")
def home():
    return send_from_directory(STATIC, "index.html")


@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    messages = data.get("messages") or []
    text = ""
    for item in reversed(messages):
        if item.get("role") == "user":
            text = item.get("content") or ""
            break
    notes = web_notes(text) if data.get("search") and text else []
    reply = model.answer(text, notes)
    return jsonify({"ok": True, "reply": reply.text, "model": reply.model, "sources": notes})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5050"))
    print(f"Universe GPT server: http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
