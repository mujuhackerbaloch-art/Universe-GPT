"""Universe GPT — a small local friend model that runs inside the Python server."""

from __future__ import annotations

import random
import re
from dataclasses import dataclass, field


@dataclass
class Reply:
    text: str
    model: str = "universe-gpt-local"


@dataclass
class UniverseGPT:
    name: str = "Universe GPT"
    memory: list[dict] = field(default_factory=list)

    def answer(self, message: str, notes: list[dict] | None = None) -> Reply:
        text = (message or "").strip()
        low = text.lower()
        notes = notes or []
        if notes:
            return Reply(self._from_notes(text, notes))
        if self._is_math(low):
            return Reply(self._math(text))
        for key, fn in (
            (("hello", "hi ", "hey", "good morning"), self._hello),
            (("black hole",), self._black_hole),
            (("planet", "solar system", "mars", "jupiter"), self._planets),
            (("fraction", "quiz"), self._fractions),
            (("experiment", "science fair"), self._experiment),
            (("story", "star map", "adventure"), self._story),
            (("homework", "explain", "what is", "who is", "why "), self._explain),
        ):
            if any(k in low for k in key):
                return Reply(fn(text))
        return Reply(self._general(text))

    def _hello(self, _text: str) -> str:
        return (
            "Hey. I am Universe GPT, your own local model running on this Python server. "
            "Ask me about space, school, a story, or a small math problem."
        )

    def _black_hole(self, _text: str) -> str:
        return (
            "A black hole is a place where gravity is so strong that light cannot escape. "
            "It can form when a very massive star collapses. The dark center is the hole. "
            "The bright ring in pictures is hot gas swirling around it."
        )

    def _planets(self, text: str) -> str:
        facts = {
            "mars": "Mars is the red planet. It is rocky, cold, and has the tallest volcano in the solar system, Olympus Mons.",
            "jupiter": "Jupiter is the biggest planet. It is a gas giant with a giant storm called the Great Red Spot.",
        }
        for name, fact in facts.items():
            if name in text.lower():
                return fact
        return (
            "Our solar system has eight planets. The rocky ones are Mercury, Venus, Earth, and Mars. "
            "The giants are Jupiter, Saturn, Uranus, and Neptune."
        )

    def _fractions(self, _text: str) -> str:
        return (
            "Fraction quiz from Universe GPT:\n"
            "1. What is 1/2 of 8?\n"
            "2. Which is bigger, 1/3 or 1/4?\n"
            "3. Simplify 2/4.\n"
            "Send your answers and I will check them."
        )

    def _experiment(self, _text: str) -> str:
        return (
            "Home science idea: sink or float.\n"
            "1. Fill a clear bowl with water.\n"
            "2. Write a guess for a coin, a grape, and a plastic lid.\n"
            "3. Test each one and record what happened.\n"
            "That is a real experiment because you predicted first, then checked."
        )

    def _story(self, _text: str) -> str:
        return (
            "Nova found a torn star map in a library book. Each night, one missing star glowed on the page. "
            "She followed the lights to the hill, set up a small telescope, and saw a cluster no one in her class had named. "
            "She called it the Friend Cluster and taped the map back together."
        )

    def _explain(self, text: str) -> str:
        topic = re.sub(r"^(please |can you |could you )?(explain|what is|who is|why is|why)\s+", "", text, flags=re.I)
        topic = topic.strip(" ?.") or "that"
        return (
            f"Here is a simple take on {topic}. "
            "Break it into three parts: what it is, why it matters, and one example. "
            "If you tell me your grade, I can make the next answer shorter or deeper. "
            "I am the local Universe GPT model on your server, so I keep answers clear and friendly."
        )

    def _general(self, text: str) -> str:
        starters = [
            "I am with you.",
            "Good question.",
            "Let us think it through.",
        ]
        return (
            f"{random.choice(starters)} You said: {text}\n\n"
            "I am Universe GPT, the model built into this Python server. "
            "I can help with space facts, a short story, a fraction quiz, a home experiment, or simple math. "
            "Ask one of those and I will answer directly."
        )

    def _from_notes(self, text: str, notes: list[dict]) -> str:
        lines = [f"- {n.get('title', 'Note')}: {n.get('snippet', '')}" for n in notes[:3]]
        return (
            f"I checked a few web notes for “{text}”.\n"
            + "\n".join(lines)
            + "\n\nThat is the short version from Universe GPT. Ask me to make it simpler if you want."
        )

    def _is_math(self, low: str) -> bool:
        return bool(re.search(r"\d\s*[\+\-\*/x×÷]\s*\d", low)) or low.startswith("what is ") and any(c.isdigit() for c in low)

    def _math(self, text: str) -> str:
        cleaned = text.lower().replace("x", "*").replace("×", "*").replace("÷", "/").replace("what is", "")
        match = re.search(r"(-?\d+(?:\.\d+)?)\s*([\+\-\*/])\s*(-?\d+(?:\.\d+)?)", cleaned)
        if not match:
            return "I can do simple sums like 12 * 4 or 9 + 7. Send one of those."
        a, op, b = float(match.group(1)), match.group(2), float(match.group(3))
        if op == "+":
            value = a + b
        elif op == "-":
            value = a - b
        elif op == "*":
            value = a * b
        else:
            if b == 0:
                return "I cannot divide by zero."
            value = a / b
        shown = int(value) if value.is_integer() else round(value, 4)
        return f"{match.group(1)} {op} {match.group(3)} = {shown}"
