const $ = (id) => document.getElementById(id);
const messages = [];

function render() {
  const thread = $("thread");
  if (!messages.length) {
    thread.innerHTML = `<div class="welcome"><h2>How can I help you today?</h2><div class="ideas">
      <button type="button" data-q="Explain black holes in a simple way">Explain black holes simply</button>
      <button type="button" data-q="Quiz me on fractions">Quiz me on fractions</button>
      <button type="button" data-q="What is 12 * 4?">Ask a math question</button>
      <button type="button" data-q="Tell me a short star map story">Tell a star-map story</button>
    </div></div>`;
    return;
  }
  thread.innerHTML = messages.map((m) => `<article class="msg ${m.role}">${m.content.replace(/[&<>]/g, (c) => ({"&":"&","<":"<",">":">"}[c]))}</article>`).join("");
  thread.scrollTop = thread.scrollHeight;
}

async function send(text) {
  text = text.trim();
  if (!text) return;
  messages.push({ role: "user", content: text });
  $("input").value = "";
  render();
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, search: $("searchToggle").checked })
  });
  const data = await res.json();
  messages.push({ role: "assistant", content: data.reply || "I could not answer that." });
  $("modelTag").textContent = data.model || "local model";
  render();
  if (window.speechSynthesis && $("callOn")) {
    const utter = new SpeechSynthesisUtterance(data.reply);
    speechSynthesis.cancel();
    speechSynthesis.speak(utter);
  }
}

$("startBtn").onclick = () => {
  $("gate").classList.add("hidden");
  $("app").classList.remove("hidden");
  render();
};
$("composer").onsubmit = (event) => { event.preventDefault(); send($("input").value); };
$("thread").onclick = (event) => { if (event.target.dataset.q) send(event.target.dataset.q); };
$("callBtn").onclick = () => {
  window.callOn = true;
  const line = "Hey, I am Universe GPT, your local model. Ask me something.";
  if (window.speechSynthesis) speechSynthesis.speak(new SpeechSynthesisUtterance(line));
};
