# Universe GPT

Own local AI model plus a Python server.

## Run on a computer

```bash
cd universe-gpt
python -m pip install -r requirements.txt
python server.py
```

Open http://127.0.0.1:5050

On a phone on the same Wi-Fi, open http://YOUR-COMPUTER-IP:5050

Do not open the HTML file by itself. The phone screenshot was unstyled because the server was not serving the page.
